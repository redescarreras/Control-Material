// ===== VARIABLES GLOBALES =====
let albaranes = [];
let albaranSeleccionado = null;
let cables = [];
let subconductos = [];
let devoluciones = [];

// ===== INICIALIZACIÓN =====
document.addEventListener('DOMContentLoaded', function() {
    console.log('🚀 Iniciando aplicación...');
    
    // Cargar todos los datos primero
    cargarAlbaranes();
    cargarMateriales();
    cargarDevoluciones();
    
    // Configurar event listeners
    configurarEventListeners();
    establecerFechaActual();
    

    
    // Mostrar datos y actualizar contadores con un pequeño delay para asegurar que todo esté cargado
    mostrarAlbaranes();
    actualizarStockDisplay('cable');
    actualizarStockDisplay('subconducto');
    
    // Actualizar contadores después de un pequeño delay para asegurar sincronización
    setTimeout(() => {
        actualizarContadores();
        console.log('🔄 Contadores actualizados al cargar página');
    }, 100);
});

// ===== GESTIÓN DE ALBARANES =====
function cargarAlbaranes() {
    const datos = localStorage.getItem('albaranes');
    if (datos) {
        albaranes = JSON.parse(datos);
    }
}

function guardarAlbaranes() {
    localStorage.setItem('albaranes', JSON.stringify(albaranes));
}

function generarIdAlbaran() {
    const fecha = new Date();
    const año = fecha.getFullYear();
    const mes = String(fecha.getMonth() + 1).padStart(2, '0');
    const dia = String(fecha.getDate()).padStart(2, '0');
    const contador = albaranes.length + 1;
    return `ALB-${año}${mes}${dia}-${String(contador).padStart(3, '0')}`;
}

// ===== GESTIÓN DE MATERIALES =====
function cargarMateriales() {
    const datosCables = localStorage.getItem('cables');
    if (datosCables) {
        cables = JSON.parse(datosCables);
    }
    
    const datosSubconductos = localStorage.getItem('subconductos');
    if (datosSubconductos) {
        subconductos = JSON.parse(datosSubconductos);
    }
}

function guardarMateriales() {
    localStorage.setItem('cables', JSON.stringify(cables));
    localStorage.setItem('subconductos', JSON.stringify(subconductos));
}

// ===== GESTIÓN DE DEVOLUCIONES =====
function cargarDevoluciones() {
    const datos = localStorage.getItem('devoluciones');
    if (datos) {
        devoluciones = JSON.parse(datos);
    }
}

function guardarDevoluciones() {
    localStorage.setItem('devoluciones', JSON.stringify(devoluciones));
}

function generarIdDevolucion() {
    const fecha = new Date();
    const año = fecha.getFullYear();
    const mes = String(fecha.getMonth() + 1).padStart(2, '0');
    const dia = String(fecha.getDate()).padStart(2, '0');
    const contador = devoluciones.length + 1;
    return `DEV-${año}${mes}${dia}-${String(contador).padStart(3, '0')}`;
}

function generarIdMaterial(tipo) {
    const fecha = new Date();
    const año = fecha.getFullYear();
    const mes = String(fecha.getMonth() + 1).padStart(2, '0');
    const dia = String(fecha.getDate()).padStart(2, '0');
    const contador = tipo === 'cable' ? cables.length + 1 : subconductos.length + 1;
    return `${tipo === 'cable' ? 'CAB' : 'SUB'}-${año}${mes}${dia}-${String(contador).padStart(3, '0')}`;
}

// ===== EVENT LISTENERS =====
function configurarEventListeners() {
    // Navegación por pestañas
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const tab = this.dataset.tab;
            cambiarTab(tab);
        });
    });

    // Modal nuevo albarán
    document.getElementById('btnNuevoAlbaran').addEventListener('click', abrirModalNuevoAlbaran);
    document.getElementById('formNuevoAlbaran').addEventListener('submit', crearAlbaran);

    // Modal nuevo cable instalación
    document.getElementById('btnNuevoCableInstalacion').addEventListener('click', abrirModalCableInstalacion);
    document.getElementById('formNuevoCable').addEventListener('submit', function(e) {
        e.preventDefault();
        agregarMaterial('cable', new FormData(e.target), 'instalacion');
        cerrarModalCable();
    });

    // Modal entrada cable
    document.getElementById('btnEntradaCable').addEventListener('click', abrirModalEntradaCable);
    document.getElementById('formEntradaCable').addEventListener('submit', function(e) {
        e.preventDefault();
        agregarMaterial('cable', new FormData(e.target), 'entrada');
        cerrarModalEntradaCable();
    });

    // Modal nuevo subconducto instalación
    document.getElementById('btnNuevoSubconductoInstalacion').addEventListener('click', abrirModalSubconductoInstalacion);
    document.getElementById('formNuevoSubconducto').addEventListener('submit', function(e) {
        e.preventDefault();
        agregarMaterial('subconducto', new FormData(e.target), 'instalacion');
        cerrarModalSubconducto();
    });

    // Modal entrada subconducto
    document.getElementById('btnEntradaSubconducto').addEventListener('click', abrirModalEntradaSubconducto);
    document.getElementById('formEntradaSubconducto').addEventListener('submit', function(e) {
        e.preventDefault();
        agregarMaterial('subconducto', new FormData(e.target), 'entrada');
        cerrarModalEntradaSubconducto();
    });

    // Modal nueva devolución
    document.getElementById('btnNuevaDevolucion').addEventListener('click', abrirModalNuevaDevolucion);
    document.getElementById('formNuevaDevolucion').addEventListener('submit', crearDevolucion);

    // Modal recepción
    document.querySelectorAll('input[name="estadoRecepcion"]').forEach(radio => {
        radio.addEventListener('change', toggleDetalleFaltante);
    });
    
    // También configurar el event listener cuando se abre el modal
    document.getElementById('modalRecepcion').addEventListener('click', function(e) {
        if (e.target === this) {
            // Modal abierto, configurar listeners de radios
            setTimeout(() => {
                document.querySelectorAll('input[name="estadoRecepcion"]').forEach(radio => {
                    radio.removeEventListener('change', toggleDetalleFaltante);
                    radio.addEventListener('change', toggleDetalleFaltante);
                });
            }, 100);
        }
    });

    // Cerrar modales con clic fuera
    document.querySelectorAll('.modal').forEach(modal => {
        modal.addEventListener('click', function(e) {
            if (e.target === modal) {
                cerrarModal();
                cerrarModalRecepcion();
                cerrarModalCable();
                cerrarModalSubconducto();
                cerrarModalEntradaCable();
                cerrarModalEntradaSubconducto();
                cerrarModalDevolucion();
                cerrarModalBuscador();
                cerrarModalImportar();
            }
        });
    });

    // Cerrar modales con ESC
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            cerrarModal();
            cerrarModalRecepcion();
            cerrarModalCable();
            cerrarModalSubconducto();
            cerrarModalEntradaCable();
            cerrarModalEntradaSubconducto();
            cerrarModalDevolucion();
            cerrarModalBuscador();
            cerrarModalImportar();
        }
    });

}

// ===== NAVEGACIÓN POR PESTAÑAS =====
function cambiarTab(tab) {
    // Actualizar botones de pestaña
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    document.querySelector(`[data-tab="${tab}"]`).classList.add('active');

    // Actualizar contenido
    document.querySelectorAll('.tab-content').forEach(content => {
        content.classList.remove('active');
    });
    document.getElementById(`tab-${tab}`).classList.add('active');

    // Actualizar contadores siempre que se cambie de pestaña
    actualizarContadores();

    // Actualizar contenido mostrado
    if (tab === 'cables') {
        mostrarMateriales('cable');
        actualizarStockDisplay('cable');
    } else if (tab === 'subconductos') {
        mostrarMateriales('subconducto');
        actualizarStockDisplay('subconducto');
    } else if (tab === 'devoluciones') {
        mostrarDevoluciones();
    } else {
        mostrarAlbaranes();
    }
}

function actualizarContadores() {
    // Obtener datos actualizados desde localStorage
    cargarAlbaranes();
    cargarMateriales();
    cargarDevoluciones();
    
    const pendientes = albaranes.filter(a => a.estado === 'pendiente').length;
    const recibidos = albaranes.filter(a => a.estado === 'recibido').length;
    const faltantes = albaranes.filter(a => a.estado === 'faltante').length;
    const cableCount = cables.length;
    const subconductoCount = subconductos.length;
    const devolucionCount = devoluciones.length;

    // Actualizar elementos con verificación de existencia
    const elements = {
        'count-pendientes': pendientes,
        'count-recibidos': recibidos,
        'count-faltantes': faltantes,
        'count-cables': cableCount,
        'count-subconductos': subconductoCount,
        'count-devoluciones': devolucionCount
    };

    for (const [id, valor] of Object.entries(elements)) {
        const element = document.getElementById(id);
        if (element) {
            element.textContent = valor;
        } else {
            console.warn(`⚠️ Elemento con ID '${id}' no encontrado en el DOM`);
        }
    }
    
    // Debug info
    console.log('📊 Contadores actualizados:', {
        pendientes,
        recibidos,
        faltantes,
        cables: cableCount,
        subconductos: subconductoCount,
        devoluciones: devolucionCount,
        totalAlbaranes: albaranes.length,
        totalCables: cables.length,
        totalSubconductos: subconductos.length,
        totalDevoluciones: devoluciones.length
    });
}

// ===== GESTIÓN DE ALBARANES =====
function crearAlbaran(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const albaran = {
        id: generarIdAlbaran(),
        idObra: formData.get('idObra'),
        fecha: formData.get('fecha'),
        cuentaCargo: formData.get('cuentaCargo'),
        tipoInstalacion: formData.get('tipoInstalacion'),
        jefeObra: formData.get('jefeObra') || '',
        observaciones: formData.get('observaciones') || '',
        estado: 'pendiente',
        fechaCreacion: new Date().toISOString(),
        fechaRecepcion: null,
        materialFaltante: null
    };

    albaranes.push(albaran);
    guardarAlbaranes();
    cerrarModal();
    actualizarContadores();
    mostrarAlbaranes();
    mostrarToast('Albarán creado correctamente', 'success');
}

function eliminarAlbaran(id) {
    if (confirm('¿Estás seguro de que quieres eliminar este albarán?')) {
        albaranes = albaranes.filter(a => a.id !== id);
        guardarAlbaranes();
        actualizarContadores();
        mostrarAlbaranes();
        mostrarToast('Albarán eliminado correctamente', 'success');
    }
}

// ===== MOSTRAR ALBARANES =====
function mostrarAlbaranes() {
    const tabActiva = document.querySelector('.tab-btn.active').dataset.tab;
    const contenedor = document.getElementById(`lista-${tabActiva}`);
    
    let albaranesMostrar = [];
    
    switch(tabActiva) {
        case 'pendientes':
            albaranesMostrar = albaranes.filter(a => a.estado === 'pendiente');
            break;
        case 'recibidos':
            albaranesMostrar = albaranes.filter(a => a.estado === 'recibido');
            break;
        case 'faltantes':
            albaranesMostrar = albaranes.filter(a => a.estado === 'recibido' && a.materialFaltante);
            break;
        default:
            albaranesMostrar = [];
    }

    if (albaranesMostrar.length === 0) {
        contenedor.innerHTML = `
            <div class="empty-state" style="text-align: center; padding: 60px 20px; color: var(--neutral-600);">
                <div style="font-size: 64px; margin-bottom: 20px;">📋</div>
                <h3 style="margin-bottom: 10px; color: var(--neutral-900);">
                    ${tabActiva === 'pendientes' ? 'No hay albaranes pendientes' :
                      tabActiva === 'recibidos' ? 'No hay albaranes recibidos' :
                      'No hay albaranes con material faltante'}
                </h3>
                <p>
                    ${tabActiva === 'pendientes' ? 'Los albaranes nuevos aparecerán aquí' :
                      tabActiva === 'recibidos' ? 'Los albaranes confirmados aparecerán aquí' :
                      'Los albaranes con problemas aparecerán aquí'}
                </p>
            </div>
        `;
        return;
    }

    contenedor.innerHTML = albaranesMostrar.map(albaran => crearTarjetaAlbaran(albaran)).join('');
}

function crearTarjetaAlbaran(albaran) {
    const fechaFormateada = new Date(albaran.fecha).toLocaleDateString('es-ES');
    const tieneMaterialFaltante = albaran.materialFaltante;
    const estadoClass = albaran.estado === 'pendiente' ? 'status-pendiente' : 
                       tieneMaterialFaltante ? 'status-faltante' : 'status-recibido';
    const estadoText = albaran.estado === 'pendiente' ? 'Pendiente' : 
                      tieneMaterialFaltante ? 'Recibido c/Faltante' : 'Recibido';

    let materialFaltanteHtml = '';
    if (tieneMaterialFaltante) {
        materialFaltanteHtml = `
            <div class="observaciones">
                <strong>Material Faltante:</strong> ${albaran.materialFaltante}
            </div>
        `;
    }

    let observacionesHtml = '';
    if (albaran.observaciones) {
        observacionesHtml = `
            <div class="observaciones">
                <strong>Observaciones:</strong> ${albaran.observaciones}
            </div>
        `;
    }

    let fechaRecepcionHtml = '';
    if (albaran.fechaRecepcion) {
        const fechaRecepcion = new Date(albaran.fechaRecepcion).toLocaleDateString('es-ES');
        fechaRecepcionHtml = `
            <div class="info-row">
                <span class="info-label">Recibido:</span>
                <span class="info-value">${fechaRecepcion}</span>
            </div>
        `;
    }

    let accionesHtml = '';
    if (albaran.estado === 'pendiente') {
        accionesHtml = `
            <div class="albaran-actions">
                <button class="btn btn-success" onclick="abrirModalRecepcion('${albaran.id}')">
                    ✅ Material Recibido
                </button>
                <button class="btn btn-secondary" onclick="eliminarAlbaran('${albaran.id}')">
                    🗑️ Eliminar
                </button>
            </div>
        `;
    } else if (tieneMaterialFaltante) {
        accionesHtml = `
            <div class="albaran-actions">
                <button class="btn btn-success" onclick="marcarFaltanteRecibido('${albaran.id}')">
                    ✅ Material Faltante Recibido
                </button>
                <button class="btn btn-secondary" onclick="eliminarAlbaran('${albaran.id}')">
                    🗑️ Eliminar
                </button>
            </div>
        `;
    } else {
        accionesHtml = `
            <div class="albaran-actions">
                <button class="btn btn-secondary" onclick="eliminarAlbaran('${albaran.id}')">
                    🗑️ Eliminar
                </button>
            </div>
        `;
    }

    return `
        <div class="albaran-card">
            <div class="albaran-header">
                <div class="albaran-id">${albaran.id}</div>
                <div class="status-badge ${estadoClass}">${estadoText}</div>
            </div>
            <div class="albaran-info">
                <div class="info-row">
                    <span class="info-label">ID Obra:</span>
                    <span class="info-value">${albaran.idObra}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Fecha:</span>
                    <span class="info-value">${fechaFormateada}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Cuenta Cargo:</span>
                    <span class="info-value">${albaran.cuentaCargo}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Tipo Instalación:</span>
                    <span class="info-value">${albaran.tipoInstalacion}</span>
                </div>
                ${albaran.jefeObra ? `
                <div class="info-row">
                    <span class="info-label">Jefe de Obra:</span>
                    <span class="info-value">${albaran.jefeObra}</span>
                </div>
                ` : ''}
                ${fechaRecepcionHtml}
                ${materialFaltanteHtml}
                ${observacionesHtml}
            </div>
            ${accionesHtml}
        </div>
    `;
}

// ===== MODALES =====
function abrirModalNuevoAlbaran() {
    document.getElementById('modalNuevoAlbaran').classList.add('active');
    document.getElementById('idObra').focus();
}

function cerrarModal() {
    document.getElementById('modalNuevoAlbaran').classList.remove('active');
    document.getElementById('formNuevoAlbaran').reset();
}

function abrirModalRecepcion(albaranId) {
    albaranSeleccionado = albaranes.find(a => a.id === albaranId);
    if (!albaranSeleccionado) return;

    const infoHtml = `
        <h4 style="margin-bottom: 16px; color: var(--neutral-900);">Albarán: ${albaranSeleccionado.id}</h4>
        <div class="info-row">
            <span class="info-label">ID Obra:</span>
            <span class="info-value">${albaranSeleccionado.idObra}</span>
        </div>
        <div class="info-row">
            <span class="info-label">Fecha:</span>
            <span class="info-value">${new Date(albaranSeleccionado.fecha).toLocaleDateString('es-ES')}</span>
        </div>
        <div class="info-row">
            <span class="info-label">Cuenta Cargo:</span>
            <span class="info-value">${albaranSeleccionado.cuentaCargo}</span>
        </div>
        <div class="info-row">
            <span class="info-label">Tipo Instalación:</span>
            <span class="info-value">${albaranSeleccionado.tipoInstalacion}</span>
        </div>
        ${albaranSeleccionado.jefeObra ? `
            <div class="info-row">
                <span class="info-label">Jefe de Obra:</span>
                <span class="info-value">${albaranSeleccionado.jefeObra}</span>
            </div>
        ` : ''}
        ${albaranSeleccionado.observaciones ? `
            <div style="margin-top: 16px; padding-top: 16px; border-top: 1px solid var(--neutral-300);">
                <strong>Observaciones:</strong> ${albaranSeleccionado.observaciones}
            </div>
        ` : ''}
    `;

    document.getElementById('infoAlbaranRecepcion').innerHTML = infoHtml;
    document.getElementById('modalRecepcion').classList.add('active');
}

function cerrarModalRecepcion() {
    document.getElementById('modalRecepcion').classList.remove('active');
    document.getElementById('materialFaltante').value = '';
    albaranSeleccionado = null;
}

function toggleDetalleFaltante() {
    const radioIncompleto = document.querySelector('input[name="estadoRecepcion"][value="incompleto"]');
    const detalleDiv = document.getElementById('detalleFaltante');
    
    if (radioIncompleto.checked) {
        detalleDiv.style.display = 'block';
        document.getElementById('materialFaltante').focus();
    } else {
        detalleDiv.style.display = 'none';
        document.getElementById('materialFaltante').value = '';
    }
}

function confirmarRecepcion() {
    if (!albaranSeleccionado) return;

    const estadoRecepcion = document.querySelector('input[name="estadoRecepcion"]:checked').value;
    const materialFaltante = document.getElementById('materialFaltante').value;

    if (estadoRecepcion === 'incompleto' && !materialFaltante.trim()) {
        mostrarToast('Por favor, especifica qué material faltó', 'error');
        return;
    }

    // Actualizar albarán
    albaranSeleccionado.estado = 'recibido'; // Siempre recibido, independientemente del material faltante
    albaranSeleccionado.fechaRecepcion = new Date().toISOString();
    if (materialFaltante.trim()) {
        albaranSeleccionado.materialFaltante = materialFaltante.trim();
    } else {
        albaranSeleccionado.materialFaltante = null;
    }

    guardarAlbaranes();
    actualizarContadores();
    mostrarAlbaranes();
    cerrarModalRecepcion();

    const mensaje = estadoRecepcion === 'completo' ? 
        'Material recibido correctamente' : 
        'Recepción marcada como incompleta';
    mostrarToast(mensaje, estadoRecepcion === 'completo' ? 'success' : 'warning');
}

function marcarFaltanteRecibido(id) {
    const albaran = albaranes.find(a => a.id === id);
    if (!albaran) return;
    
    if (confirm('¿Confirmas que el material faltante ya fue recibido?')) {
        albaran.materialFaltante = null;
        guardarAlbaranes();
        actualizarContadores();
        mostrarAlbaranes();
        mostrarToast('Material faltante marcado como recibido', 'success');
    }
}

// ===== UTILIDADES =====
function establecerFechaActual() {
    const hoy = new Date().toISOString().split('T')[0];
    document.getElementById('fecha').value = hoy;
    
    // Establecer fechas por defecto en formularios de materiales
    document.getElementById('fechaCable').value = hoy;
    document.getElementById('fechaSubconducto').value = hoy;
    document.getElementById('fechaDevolucion').value = hoy;
}

function mostrarToast(mensaje, tipo = 'info') {
    const toastContainer = document.getElementById('toast-container');
    const toast = document.createElement('div');
    toast.className = `toast ${tipo}`;
    toast.innerHTML = `
        <div style="display: flex; justify-content: space-between; align-items: center;">
            <span>${mensaje}</span>
            <button onclick="this.parentElement.parentElement.remove()" style="background: none; border: none; cursor: pointer; font-size: 18px; color: var(--neutral-600);">&times;</button>
        </div>
    `;
    
    toastContainer.appendChild(toast);

    // Auto-remove después de 5 segundos
    setTimeout(() => {
        if (toast.parentNode) {
            toast.remove();
        }
    }, 5000);
}

// ===== GESTIÓN DE DEVOLUCIONES MÚLTIPLES =====
function inicializarBobinas() {
    const container = document.getElementById('bobinasContainer');
    container.innerHTML = '';
    agregarBobina(); // Añadir la primera bobina por defecto
}

function agregarBobina() {
    const container = document.getElementById('bobinasContainer');
    const bobinaIndex = container.children.length + 1;
    
    const bobinaHTML = `
        <div class="bobina-item" data-bobina="${bobinaIndex}">
            <div class="bobina-header">
                <div class="bobina-title">Bobina ${bobinaIndex}</div>
                ${bobinaIndex > 1 ? `<button type="button" class="btn-eliminar-bobina" onclick="eliminarBobina(${bobinaIndex})">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <line x1="18" y1="6" x2="6" y2="18"></line>
                        <line x1="6" y1="6" x2="18" y2="18"></line>
                    </svg>
                    Eliminar
                </button>` : ''}
            </div>
            <div class="campos-bobina">
                <div class="form-group">
                    <label for="metrosBobina_${bobinaIndex}">Metros de la Bobina *</label>
                    <input type="number" id="metrosBobina_${bobinaIndex}" name="metrosBobina_${bobinaIndex}" required min="0" step="0.1" placeholder="Ej: 2000.0">
                </div>
                <div class="form-group">
                    <label class="checkbox-label">
                        <input type="checkbox" id="entregaVacia_${bobinaIndex}" name="entregaVacia_${bobinaIndex}">
                        <span class="checkbox-custom"></span>
                        Entrega Vacía
                    </label>
                </div>
            </div>
            <div class="form-group">
                <label for="tipoMaterial_${bobinaIndex}">Tipo de Material a Devolver *</label>
                <select id="tipoMaterial_${bobinaIndex}" name="tipoMaterial_${bobinaIndex}" required onchange="toggleCamposMaterial(${bobinaIndex})">
                    <option value="">Seleccionar tipo de material...</option>
                    <option value="bobina_con_cable">Bobinas con cable</option>
                    <option value="bobina_vacia">Bobina vacía</option>
                    <option value="otro">Otro tipo de material</option>
                </select>
            </div>
            <div id="camposBobinaCable_${bobinaIndex}" class="campos-bobina" style="display: none;">
                <div class="form-group">
                    <label for="tipoCableDevolucion_${bobinaIndex}">Tipo de Cable *</label>
                    <select id="tipoCableDevolucion_${bobinaIndex}" name="tipoCableDevolucion_${bobinaIndex}" required>
                        <option value="">Seleccionar tipo de cable...</option>
                        <option value="Cable de f.o. de exterior PKP holgado de 8 fo.">Cable de f.o. de exterior PKP holgado de 8 fo.</option>
                        <option value="Cable de f.o. de exterior PKP holgado de 16 fo.">Cable de f.o. de exterior PKP holgado de 16 fo.</option>
                        <option value="Cable de f.o. de exterior PKP holgado de 24 fo.">Cable de f.o. de exterior PKP holgado de 24 fo.</option>
                        <option value="Cable de f.o. de exterior PKP holgado de 32 fo.">Cable de f.o. de exterior PKP holgado de 32 fo.</option>
                        <option value="Cable de f.o. de exterior PKP holgado de 48 fo.">Cable de f.o. de exterior PKP holgado de 48 fo.</option>
                        <option value="Cable de f.o. de exterior PKP holgado de 64 fo.">Cable de f.o. de exterior PKP holgado de 64 fo.</option>
                        <option value="Cable de f.o. de exterior PKP holgado de 128 fo.">Cable de f.o. de exterior PKP holgado de 128 fo.</option>
                        <option value="Cable de f.o. de exterior PKP holgado de 256 fo.">Cable de f.o. de exterior PKP holgado de 256 fo.</option>
                        <option value="Cable de f.o. de exterior PKP holgado de 512 fo.">Cable de f.o. de exterior PKP holgado de 512 fo.</option>
                        <option value="Cable de f.o. de exterior KP holgado de 768 fo.">Cable de f.o. de exterior KP holgado de 768 fo.</option>
                        <option value="Cable de f.o. de exterior KP compacto de 864 fo.">Cable de f.o. de exterior KP compacto de 864 fo.</option>
                        <option value="Cable de f.o. de exterior KP compacto de 912 fo.">Cable de f.o. de exterior KP compacto de 912 fo.</option>
                        <option value="Cable de f.o. de interior KT de 8 fo.">Cable de f.o. de interior KT de 8 fo.</option>
                        <option value="Cable de f.o. de interior TKT de 16 fo.">Cable de f.o. de interior TKT de 16 fo.</option>
                        <option value="Cable de f.o. de interior TKT de 24 fo.">Cable de f.o. de interior TKT de 24 fo.</option>
                        <option value="Cable de f.o. de interior TKT de 32 fo.">Cable de f.o. de interior TKT de 32 fo.</option>
                        <option value="Cable de f.o. de interior TKT de 48 fo.">Cable de f.o. de interior TKT de 48 fo.</option>
                        <option value="Cable de f.o. de interior TKT de 64 fo.">Cable de f.o. de interior TKT de 64 fo.</option>
                        <option value="Cable de f.o. de interior TKT de 128 fo.">Cable de f.o. de interior TKT de 128 fo.</option>
                        <option value="Cable de f.o. de interior TKT de 256 fo.">Cable de f.o. de interior TKT de 256 fo.</option>
                        <option value="Cable de f.o. de interior KT de 512 fo.">Cable de f.o. de interior KT de 512 fo.</option>
                        <option value="Cable de f.o. 16 VT.">Cable de f.o. 16 VT.</option>
                        <option value="Cable de f.o. 32 VT.">Cable de f.o. 32 VT.</option>
                        <option value="Cable de f.o. 64 VT.">Cable de f.o. 64 VT.</option>
                        <option value="Cable KT 8 fo G.652.D monotubo BLANCO">Cable KT 8 fo G.652.D monotubo BLANCO</option>
                        <option value="Cable KP 16 fo G.652.D (4x4f+2e) BLANCO">Cable KP 16 fo G.652.D (4x4f+2e) BLANCO</option>
                        <option value="Cable FVT micromódulos 16 fo G.657 A2 (4x4f) BLANCO">Cable FVT micromódulos 16 fo G.657 A2 (4x4f) BLANCO</option>
                        <option value="Cable KP 32 fo G.652.D (8x4f) BLANCO">Cable KP 32 fo G.652.D (8x4f) BLANCO</option>
                        <option value="Cable FVT micromódulos 32 fo G.657 A2 (8x4f) BLANCO">Cable FVT micromódulos 32 fo G.657 A2 (8x4f) BLANCO</option>
                        <option value="Cable KP 64 fo G.652.D (8x8f) BLANCO">Cable KP 64 fo G.652.D (8x8f) BLANCO</option>
                        <option value="Cable FVT micromódulos 64 fo G.657 A2 (8x8f) BLANCO">Cable FVT micromódulos 64 fo G.657 A2 (8x8f) BLANCO</option>
                        <option value="Cable de f.o. de interior riser de 16 fo.">Cable de f.o. de interior riser de 16 fo.</option>
                        <option value="Cable de f.o. de interior riser de 24 fo.">Cable de f.o. de interior riser de 24 fo.</option>
                        <option value="Cable de f.o. de interior riser de 32 fo.">Cable de f.o. de interior riser de 32 fo.</option>
                        <option value="Cable de f.o. de interior riser de 48 fo.">Cable de f.o. de interior riser de 48 fo.</option>
                        <option value="Cable de f.o. de exterior KP holgado de 16 fo.">Cable de f.o. de exterior KP holgado de 16 fo.</option>
                        <option value="Cable de f.o. de exterior KP holgado de 32 fo.">Cable de f.o. de exterior KP holgado de 32 fo.</option>
                        <option value="Cable de f.o. de exterior KP holgado de 64 fo.">Cable de f.o. de exterior KP holgado de 64 fo.</option>
                        <option value="Cable de f.o. de exterior KP holgado de 128 fo.">Cable de f.o. de exterior KP holgado de 128 fo.</option>
                        <option value="Cable de f.o. de exterior riser de 16 fo.">Cable de f.o. de exterior riser de 16 fo.</option>
                        <option value="Cable de f.o. de exterior riser de 32 fo.">Cable de f.o. de exterior riser de 32 fo.</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="numeroMatriculaCable_${bobinaIndex}">Número de Matrícula *</label>
                    <input type="text" id="numeroMatriculaCable_${bobinaIndex}" name="numeroMatriculaCable_${bobinaIndex}" placeholder="Ej: MAT-001-2024">
                </div>
                <div class="form-group">
                    <label for="metrosCable_${bobinaIndex}">Metros de Cable *</label>
                    <input type="number" id="metrosCable_${bobinaIndex}" name="metrosCable_${bobinaIndex}" min="0" step="0.1" placeholder="Ej: 1800.5">
                </div>
            </div>
            <div id="camposBobinaVacia_${bobinaIndex}" class="form-group" style="display: none;">
                <label for="numeroMatriculaVacia_${bobinaIndex}">Número de Matrícula *</label>
                <input type="text" id="numeroMatriculaVacia_${bobinaIndex}" name="numeroMatriculaVacia_${bobinaIndex}" placeholder="Ej: MAT-002-2024">
            </div>
            <div id="camposOtroMaterial_${bobinaIndex}" class="form-group" style="display: none;">
                <label for="descripcionOtroMaterial_${bobinaIndex}">Descripción del Material *</label>
                <input type="text" id="descripcionOtroMaterial_${bobinaIndex}" name="descripcionOtroMaterial_${bobinaIndex}" placeholder="Ej: Cables de conexión, conectores, etc.">
            </div>
        </div>
    `;
    
    container.insertAdjacentHTML('beforeend', bobinaHTML);
}

function eliminarBobina(bobinaIndex) {
    const container = document.getElementById('bobinasContainer');
    const bobinaItem = container.querySelector(`[data-bobina="${bobinaIndex}"]`);
    if (bobinaItem) {
        bobinaItem.remove();
        // Renumerar las bobinas restantes
        renumerarBobinas();
    }
}

function renumerarBobinas() {
    const container = document.getElementById('bobinasContainer');
    const bobinas = container.querySelectorAll('.bobina-item');
    
    bobinas.forEach((bobina, index) => {
        const nuevoNumero = index + 1;
        bobina.setAttribute('data-bobina', nuevoNumero);
        
        // Actualizar título
        const titulo = bobina.querySelector('.bobina-title');
        titulo.textContent = `Bobina ${nuevoNumero}`;
        
        // Actualizar botón eliminar
        const botonEliminar = bobina.querySelector('.btn-eliminar-bobina');
        if (botonEliminar) {
            botonEliminar.setAttribute('onclick', `eliminarBobina(${nuevoNumero})`);
        } else if (nuevoNumero > 1) {
            // Añadir botón eliminar si no existe
            const header = bobina.querySelector('.bobina-header');
            const botonHTML = `
                <button type="button" class="btn-eliminar-bobina" onclick="eliminarBobina(${nuevoNumero})">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <line x1="18" y1="6" x2="6" y2="18"></line>
                        <line x1="6" y1="6" x2="18" y2="18"></line>
                    </svg>
                    Eliminar
                </button>
            `;
            header.insertAdjacentHTML('beforeend', botonHTML);
        }
        
        // Actualizar IDs y names de todos los elementos
        const elementos = bobina.querySelectorAll('[id], [name]');
        elementos.forEach(elemento => {
            const id = elemento.id;
            const name = elemento.name;
            
            if (id && id.includes('_')) {
                const partes = id.split('_');
                partes[partes.length - 1] = nuevoNumero;
                elemento.id = partes.join('_');
            }
            
            if (name && name.includes('_')) {
                const partes = name.split('_');
                partes[partes.length - 1] = nuevoNumero;
                elemento.name = partes.join('_');
            }
        });
    });
}

function toggleCamposMaterial(bobinaIndex) {
    const tipoMaterial = document.getElementById(`tipoMaterial_${bobinaIndex}`).value;
    
    // Ocultar todos los campos
    document.getElementById(`camposBobinaCable_${bobinaIndex}`).style.display = 'none';
    document.getElementById(`camposBobinaVacia_${bobinaIndex}`).style.display = 'none';
    document.getElementById(`camposOtroMaterial_${bobinaIndex}`).style.display = 'none';
    
    // Limpiar valores
    document.getElementById(`tipoCableDevolucion_${bobinaIndex}`).value = '';
    document.getElementById(`numeroMatriculaCable_${bobinaIndex}`).value = '';
    document.getElementById(`metrosCable_${bobinaIndex}`).value = '';
    document.getElementById(`numeroMatriculaVacia_${bobinaIndex}`).value = '';
    document.getElementById(`descripcionOtroMaterial_${bobinaIndex}`).value = '';
    
    // Mostrar campos según la selección
    switch(tipoMaterial) {
        case 'bobina_con_cable':
            document.getElementById(`camposBobinaCable_${bobinaIndex}`).style.display = 'grid';
            document.getElementById(`tipoCableDevolucion_${bobinaIndex}`).required = true;
            document.getElementById(`numeroMatriculaCable_${bobinaIndex}`).required = true;
            document.getElementById(`metrosCable_${bobinaIndex}`).required = true;
            break;
        case 'bobina_vacia':
            document.getElementById(`camposBobinaVacia_${bobinaIndex}`).style.display = 'block';
            document.getElementById(`numeroMatriculaVacia_${bobinaIndex}`).required = true;
            break;
        case 'otro':
            document.getElementById(`camposOtroMaterial_${bobinaIndex}`).style.display = 'block';
            document.getElementById(`descripcionOtroMaterial_${bobinaIndex}`).required = true;
            break;
    }
}

function crearDevolucion(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const container = document.getElementById('bobinasContainer');
    const bobinas = container.querySelectorAll('.bobina-item');
    
    if (bobinas.length === 0) {
        mostrarToast('Debe añadir al menos una bobina', 'error');
        return;
    }
    
    // Recopilar datos de todas las bobinas
    const bobinasData = [];
    
    bobinas.forEach((bobina, index) => {
        const bobinaIndex = index + 1;
        const metrosBobina = parseFloat(formData.get(`metrosBobina_${bobinaIndex}`)) || 0;
        const entregaVacia = formData.get(`entregaVacia_${bobinaIndex}`) === 'on';
        const tipoMaterial = formData.get(`tipoMaterial_${bobinaIndex}`);
        
        if (!metrosBobina || !tipoMaterial) {
            mostrarToast(`Complete todos los campos requeridos de la bobina ${bobinaIndex}`, 'error');
            return;
        }
        
        const bobinaData = {
            metrosBobina,
            entregaVacia,
            tipoMaterial,
            tipoCableDevolucion: formData.get(`tipoCableDevolucion_${bobinaIndex}`) || '',
            numeroMatriculaCable: formData.get(`numeroMatriculaCable_${bobinaIndex}`) || '',
            metrosCableBobina: parseFloat(formData.get(`metrosCable_${bobinaIndex}`)) || 0,
            numeroMatriculaVacia: formData.get(`numeroMatriculaVacia_${bobinaIndex}`) || '',
            descripcionOtroMaterial: formData.get(`descripcionOtroMaterial_${bobinaIndex}`) || ''
        };
        
        // Validar campos específicos según el tipo
        if (tipoMaterial === 'bobina_con_cable' && (!bobinaData.tipoCableDevolucion || !bobinaData.numeroMatriculaCable || !bobinaData.metrosCableBobina)) {
            mostrarToast(`Complete todos los campos de cable para la bobina ${bobinaIndex}`, 'error');
            return;
        }
        
        if (tipoMaterial === 'bobina_vacia' && !bobinaData.numeroMatriculaVacia) {
            mostrarToast(`Complete el número de matrícula para la bobina ${bobinaIndex}`, 'error');
            return;
        }
        
        if (tipoMaterial === 'otro' && !bobinaData.descripcionOtroMaterial) {
            mostrarToast(`Complete la descripción del material para la bobina ${bobinaIndex}`, 'error');
            return;
        }
        
        bobinasData.push(bobinaData);
    });
    
    // Crear devolución con múltiples bobinas
    const devolucion = {
        id: generarIdDevolucion(),
        idObra: formData.get('idObra'),
        fechaEntrega: formData.get('fecha'),
        tipoInstalacion: formData.get('tipoInstalacion'),
        bobinas: bobinasData,
        observaciones: formData.get('observaciones') || '',
        fechaCreacion: new Date().toISOString()
    };

    devoluciones.push(devolucion);
    guardarDevoluciones();
    cerrarModalDevolucion();
    actualizarContadores();
    mostrarDevoluciones();
    mostrarToast('Devolución registrada correctamente', 'success');
}

function eliminarDevolucion(id) {
    if (confirm('¿Estás seguro de que quieres eliminar esta devolución?')) {
        devoluciones = devoluciones.filter(d => d.id !== id);
        guardarDevoluciones();
        actualizarContadores();
        mostrarDevoluciones();
        mostrarToast('Devolución eliminada correctamente', 'success');
    }
}

function mostrarDevoluciones() {
    const contenedor = document.getElementById('lista-devoluciones');
    
    if (devoluciones.length === 0) {
        contenedor.innerHTML = `
            <div class="empty-state" style="text-align: center; padding: 60px 20px; color: var(--neutral-600);">
                <div style="font-size: 64px; margin-bottom: 20px;">↩️</div>
                <h3 style="margin-bottom: 10px; color: var(--neutral-900);">
                    No hay devoluciones registradas
                </h3>
                <p>
                    Las devoluciones de bobinas y cables aparecerán aquí
                </p>
            </div>
        `;
        return;
    }

    contenedor.innerHTML = devoluciones.map(devolucion => crearTarjetaDevolucion(devolucion)).join('');
}

function crearTarjetaDevolucion(devolucion) {
    const fechaFormateada = new Date(devolucion.fechaEntrega).toLocaleDateString('es-ES');
    
    // Generar HTML para todas las bobinas
    let bobinasHtml = '';
    devolucion.bobinas.forEach((bobina, index) => {
        let tipoMaterialText = '';
        let detallesMaterial = '';
        
        switch(bobina.tipoMaterial) {
            case 'bobina_con_cable':
                tipoMaterialText = 'Bobina con Cable';
                detallesMaterial = `
                    <div class="info-row">
                        <span class="info-label">Tipo de Cable:</span>
                        <span class="info-value">${bobina.tipoCableDevolucion || 'No especificado'}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Nº Matrícula:</span>
                        <span class="info-value">${bobina.numeroMatriculaCable}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Metros de Cable:</span>
                        <span class="info-value">${bobina.metrosCableBobina} m</span>
                    </div>
                `;
                break;
            case 'bobina_vacia':
                tipoMaterialText = 'Bobina Vacía';
                detallesMaterial = `
                    <div class="info-row">
                        <span class="info-label">Nº Matrícula:</span>
                        <span class="info-value">${bobina.numeroMatriculaVacia}</span>
                    </div>
                `;
                break;
            case 'otro':
                tipoMaterialText = 'Otro Material';
                detallesMaterial = `
                    <div class="info-row">
                        <span class="info-label">Material:</span>
                        <span class="info-value">${bobina.descripcionOtroMaterial}</span>
                    </div>
                `;
                break;
        }

        let entregaVaciaText = bobina.entregaVacia ? 'SÍ' : 'NO';

        bobinasHtml += `
            <div class="bobina-info" style="margin-bottom: ${index < devolucion.bobinas.length - 1 ? 'var(--space-md)' : '0'}; padding-bottom: ${index < devolucion.bobinas.length - 1 ? 'var(--space-md)' : '0'}; border-bottom: ${index < devolucion.bobinas.length - 1 ? '1px solid var(--neutral-300)' : 'none'};">
                <div style="font-weight: 600; color: var(--primary-500); margin-bottom: var(--space-sm);">Bobina ${index + 1}</div>
                <div class="info-row">
                    <span class="info-label">Metros Bobina:</span>
                    <span class="info-value">${bobina.metrosBobina} m</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Entrega Vacía:</span>
                    <span class="info-value">${entregaVaciaText}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Material:</span>
                    <span class="info-value">${tipoMaterialText}</span>
                </div>
                ${detallesMaterial}
            </div>
        `;
    });

    let observacionesHtml = '';
    if (devolucion.observaciones) {
        observacionesHtml = `
            <div class="observaciones" style="margin-top: var(--space-md); padding-top: var(--space-md); border-top: 1px solid var(--neutral-300);">
                <strong>Observaciones:</strong> ${devolucion.observaciones}
            </div>
        `;
    }

    return `
        <div class="albaran-card">
            <div class="albaran-header">
                <div class="albaran-id">${devolucion.id}</div>
                <div class="status-badge status-recibido">Devolución</div>
            </div>
            <div class="albaran-info">
                <div class="info-row">
                    <span class="info-label">ID Obra:</span>
                    <span class="info-value">${devolucion.idObra}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Fecha Entrega:</span>
                    <span class="info-value">${fechaFormateada}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Tipo Instalación:</span>
                    <span class="info-value">${devolucion.tipoInstalacion}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Total Bobinas:</span>
                    <span class="info-value">${devolucion.bobinas.length}</span>
                </div>
                ${bobinasHtml}
                ${observacionesHtml}
            </div>
            <div class="albaran-actions">
                <button class="btn btn-secondary" onclick="eliminarDevolucion('${devolucion.id}')">
                    🗑️ Eliminar
                </button>
            </div>
        </div>
    `;
}

function abrirModalNuevaDevolucion() {
    document.getElementById('modalNuevaDevolucion').classList.add('active');
    document.getElementById('idObraDevolucion').focus();
    establecerFechaActual();
    inicializarBobinas(); // Inicializar con una bobina por defecto
}

function cerrarModalDevolucion() {
    document.getElementById('modalNuevaDevolucion').classList.remove('active');
    document.getElementById('formNuevaDevolucion').reset();
    
    // Limpiar contenedor de bobinas
    document.getElementById('bobinasContainer').innerHTML = '';
}



// ===== GESTIÓN DE CABLES Y SUBCONDUCTOS =====
function agregarMaterial(tipo, formData, accion) {
    const material = {
        id: generarIdMaterial(tipo),
        tipoMaterial: tipo,
        idObra: formData.get('idObra') || '',
        tipoCable: formData.get('tipoCable') || formData.get('tipoSubconducto') || '',
        metros: parseFloat(formData.get('metros')) || 0,
        accion: accion, // 'instalacion' o 'entrada'
        fecha: formData.get('fecha') || new Date().toISOString().split('T')[0],
        observaciones: formData.get('observaciones') || ''
    };

    if (tipo === 'cable') {
        cables.push(material);
    } else {
        subconductos.push(material);
    }
    
    guardarMateriales();
    mostrarMateriales(tipo);
    actualizarContadores();
    actualizarStockDisplay(tipo);
    
    const tipoLabel = tipo === 'cable' ? 'Cable' : 'Subconducto';
    const accionLabel = accion === 'instalacion' ? 'instalación' : 'entrada';
    mostrarToast(`${tipoLabel} de ${accionLabel} agregado correctamente`, 'success');
}

// Función eliminada - ya no se usa el sistema de "solicitado"

function eliminarMaterial(tipo, materialId) {
    if (confirm('¿Estás seguro de que quieres eliminar este material?')) {
        if (tipo === 'cable') {
            cables = cables.filter(m => m.id !== materialId);
        } else {
            subconductos = subconductos.filter(m => m.id !== materialId);
        }
        guardarMateriales();
        mostrarMateriales(tipo);
        actualizarContadores();
        actualizarStockDisplay(tipo);
        mostrarToast('Material eliminado correctamente', 'success');
    }
}

function mostrarMateriales(tipo) {
    const contenedor = document.getElementById(`lista-${tipo}s`);
    const materialArray = tipo === 'cable' ? cables : subconductos;
    
    if (materialArray.length === 0) {
        contenedor.innerHTML = `
            <div class="empty-state" style="text-align: center; padding: 60px 20px; color: var(--neutral-600);">
                <div style="font-size: 64px; margin-bottom: 20px;">${tipo === 'cable' ? '🔌' : '🛡️'}</div>
                <h3 style="margin-bottom: 10px; color: var(--neutral-900);">
                    No hay ${tipo}s registrados
                </h3>
                <p>
                    Los ${tipo}s utilizados en obras aparecerán aquí
                </p>
            </div>
        `;
        return;
    }

    // Agrupar materiales por tipo
    const materialesPorTipo = {};
    materialArray.forEach(material => {
        const tipoMaterial = material.tipoCable || material.tipoSubconducto || 'Sin especificar';
        if (!materialesPorTipo[tipoMaterial]) {
            materialesPorTipo[tipoMaterial] = [];
        }
        materialesPorTipo[tipoMaterial].push(material);
    });

    // Crear HTML con secciones por tipo
    let html = '';
    Object.keys(materialesPorTipo).sort().forEach(tipoMaterial => {
        const materiales = materialesPorTipo[tipoMaterial];
        const stock = calcularStockPorTipo(tipo === 'cable' ? 'cable' : 'subconducto')[tipoMaterial] || {recibido: 0, instalado: 0, disponible: 0};
        
        html += `
            <div class="tipo-section">
                <div class="tipo-header">
                    <h3>${tipoMaterial}</h3>
                    <div class="tipo-stock">
                        <span class="stock-item">Recibido: ${stock.recibido.toFixed(1)}m</span>
                        <span class="stock-item">Instalado: ${stock.instalado.toFixed(1)}m</span>
                        <span class="stock-item disponible">Disponible: ${stock.disponible.toFixed(1)}m</span>
                    </div>
                </div>
                <div class="materiales-grid">
                    ${materiales.map(material => crearTarjetaMaterial(material)).join('')}
                </div>
            </div>
        `;
    });

    contenedor.innerHTML = html;
}

function crearTarjetaMaterial(material) {
    const fechaFormateada = new Date(material.fecha).toLocaleDateString('es-ES');
    
    let estadoClass = '';
    let estadoText = '';
    
    if (material.accion === 'entrada') {
        estadoClass = 'status-recibido';
        estadoText = 'Entrada';
    } else if (material.accion === 'instalacion') {
        estadoClass = 'status-faltante';
        estadoText = 'Instalado';
    }

    let observacionesHtml = '';
    if (material.observaciones) {
        observacionesHtml = `
            <div class="observaciones">
                <strong>Observaciones:</strong> ${material.observaciones}
            </div>
        `;
    }

    let tipoHtml = '';
    if (material.tipoCable) {
        tipoHtml = `
            <div class="info-row">
                <span class="info-label">Tipo:</span>
                <span class="info-value">${material.tipoCable}</span>
            </div>
        `;
    }

    let idObraHtml = '';
    if (material.idObra) {
        idObraHtml = `
            <div class="info-row">
                <span class="info-label">ID Obra:</span>
                <span class="info-value">${material.idObra}</span>
            </div>
        `;
    }

    return `
        <div class="albaran-card">
            <div class="albaran-header">
                <div class="albaran-id">${material.id}</div>
                <div class="status-badge ${estadoClass}">${estadoText}</div>
            </div>
            <div class="albaran-info">
                ${idObraHtml}
                ${tipoHtml}
                <div class="info-row">
                    <span class="info-label">Metros:</span>
                    <span class="info-value">${material.metros} m</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Fecha:</span>
                    <span class="info-value">${fechaFormateada}</span>
                </div>
                ${observacionesHtml}
            </div>
            <div class="albaran-actions">
                <button class="btn btn-secondary" onclick="eliminarMaterial('${material.tipoMaterial}', '${material.id}')">
                    🗑️ Eliminar
                </button>
            </div>
        </div>
    `;
}

function calcularStock(tipo) {
    const materialArray = tipo === 'cable' ? cables : subconductos;
    
    let totalRecibido = 0;
    let totalInstalado = 0;
    
    materialArray.forEach(material => {
        if (material.accion === 'entrada') {
            totalRecibido += material.metros;
        } else if (material.accion === 'instalacion') {
            totalInstalado += material.metros;
        }
    });
    
    return {
        recibido: totalRecibido,
        instalado: totalInstalado,
        disponible: totalRecibido - totalInstalado
    };
}

function calcularStockPorTipo(tipoMaterial) {
    const materialArray = tipoMaterial === 'cable' ? cables : subconductos;
    const stockPorTipo = {};
    
    // Obtener todos los tipos únicos
    const tipos = [...new Set(materialArray.map(m => m.tipoCable || m.tipoSubconducto))];
    
    tipos.forEach(tipo => {
        const materialesDelTipo = materialArray.filter(m => (m.tipoCable || m.tipoSubconducto) === tipo);
        
        let totalRecibido = 0;
        let totalInstalado = 0;
        
        materialesDelTipo.forEach(material => {
            if (material.accion === 'entrada') {
                totalRecibido += material.metros;
            } else if (material.accion === 'instalacion') {
                totalInstalado += material.metros;
            }
        });
        
        stockPorTipo[tipo] = {
            recibido: totalRecibido,
            instalado: totalInstalado,
            disponible: totalRecibido - totalInstalado
        };
    });
    
    return stockPorTipo;
}

// ===== REPORTES PDF =====
function generarReporteMateriales(tipoMaterial) {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();

    // Configurar fuentes
    doc.setFont('helvetica');
    
    // Header
    doc.setFontSize(20);
    doc.setTextColor(255, 85, 0); // Color primario
    doc.text('Redes Carreras S.L.', 20, 30);
    
    doc.setFontSize(16);
    doc.setTextColor(0, 0, 0);
    doc.text(`Control de ${tipoMaterial === 'cable' ? 'Cables' : 'Subconductos'}`, 20, 45);
    
    doc.setFontSize(12);
    doc.setTextColor(100, 100, 100);
    const fechaReporte = new Date().toLocaleDateString('es-ES');
    doc.text(`Fecha del reporte: ${fechaReporte}`, 20, 55);
    
    let yPos = 75;
    
    const materialArray = tipoMaterial === 'cable' ? cables : subconductos;
    const stockPorTipo = calcularStockPorTipo(tipoMaterial);
    
    // Resumen por tipo
    doc.setFontSize(14);
    doc.setTextColor(0, 0, 0);
    doc.text('Stock por Tipo', 20, yPos);
    yPos += 15;
    
    Object.keys(stockPorTipo).forEach(tipo => {
        const stock = stockPorTipo[tipo];
        if (yPos > 250) {
            doc.addPage();
            yPos = 30;
        }
        
        doc.setFontSize(10);
        doc.setTextColor(255, 85, 0);
        doc.text(`${tipo}:`, 25, yPos);
        yPos += 6;
        
        doc.setTextColor(0, 0, 0);
        doc.text(`Recibidos: ${stock.recibido.toFixed(1)}m | Instalados: ${stock.instalado.toFixed(1)}m | Disponibles: ${stock.disponible.toFixed(1)}m`, 30, yPos);
        yPos += 10;
    });
    
    yPos += 15;
    
    // Tabla detallada
    if (materialArray.length > 0) {
        doc.setFontSize(14);
        doc.setTextColor(0, 0, 0);
        doc.text('Detalle de Movimientos', 20, yPos);
        yPos += 15;
        
        // Headers
        doc.setFontSize(10);
        doc.setTextColor(255, 255, 255);
        doc.setFillColor(255, 85, 0);
        doc.rect(20, yPos - 8, 170, 8, 'F');
        
        doc.text('ID', 22, yPos - 2);
        doc.text('Tipo', 45, yPos - 2);
        doc.text('Acción', 100, yPos - 2);
        doc.text('Metros', 130, yPos - 2);
        doc.text('Fecha', 155, yPos - 2);
        doc.text('Obra', 180, yPos - 2);
        
        yPos += 12;
        
        // Datos
        doc.setTextColor(0, 0, 0);
        materialArray.forEach((material, index) => {
            if (yPos > 250) {
                doc.addPage();
                yPos = 30;
            }
            
            // Alternar colores de fondo
            if (index % 2 === 0) {
                doc.setFillColor(245, 241, 230);
                doc.rect(20, yPos - 8, 170, 8, 'F');
            }
            
            const tipo = material.tipoCable || material.tipoSubconducto || 'N/A';
            const accion = material.accion === 'entrada' ? 'Entrada' : 'Instalación';
            const fecha = new Date(material.fecha).toLocaleDateString('es-ES');
            const obra = material.idObra || '-';
            
            // Ajustar texto
            const tipoText = tipo.length > 20 ? tipo.substring(0, 20) + '...' : tipo;
            const obraText = obra.length > 8 ? obra.substring(0, 8) + '...' : obra;
            
            doc.text(material.id, 22, yPos - 2);
            doc.text(tipoText, 45, yPos - 2);
            doc.text(accion, 100, yPos - 2);
            doc.text(`${material.metros}m`, 130, yPos - 2);
            doc.text(fecha, 155, yPos - 2);
            doc.text(obraText, 180, yPos - 2);
            
            yPos += 8;
        });
    }
    
    // Footer
    const pageCount = doc.internal.getNumberOfPages();
    for (let i = 1; i <= pageCount; i++) {
        doc.setPage(i);
        doc.setFontSize(8);
        doc.setTextColor(150, 150, 150);
        doc.text('Generado por Sistema de Control de Materiales - Redes Carreras S.L.', 20, 290);
        doc.text(`Página ${i} de ${pageCount}`, 170, 290);
    }
    
    // Descargar
    const nombreArchivo = `reporte_${tipoMaterial}s_${fechaReporte.replace(/\//g, '-')}.pdf`;
    doc.save(nombreArchivo);
    
    mostrarToast(`Reporte de ${tipoMaterial === 'cable' ? 'cables' : 'subconductos'} generado correctamente`, 'success');
}

function generarReporteDevoluciones() {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();

    // Configurar fuentes
    doc.setFont('helvetica');
    
    // Header
    doc.setFontSize(20);
    doc.setTextColor(255, 85, 0); // Color primario
    doc.text('Redes Carreras S.L.', 20, 30);
    
    doc.setFontSize(16);
    doc.setTextColor(0, 0, 0);
    doc.text('Control de Devoluciones', 20, 45);
    
    doc.setFontSize(12);
    doc.setTextColor(100, 100, 100);
    const fechaReporte = new Date().toLocaleDateString('es-ES');
    doc.text(`Fecha del reporte: ${fechaReporte}`, 20, 55);
    
    let yPos = 75;
    
    // Resumen general
    doc.setFontSize(14);
    doc.setTextColor(0, 0, 0);
    doc.text('Resumen General', 20, yPos);
    yPos += 15;
    
    const totalDevoluciones = devoluciones.length;
    let totalBobinas = 0;
    let bobinasConCable = 0;
    let bobinasVacias = 0;
    let otrosMateriales = 0;
    let entregasVacias = 0;
    
    devoluciones.forEach(devolucion => {
        totalBobinas += devolucion.bobinas.length;
        devolucion.bobinas.forEach(bobina => {
            switch(bobina.tipoMaterial) {
                case 'bobina_con_cable':
                    bobinasConCable++;
                    break;
                case 'bobina_vacia':
                    bobinasVacias++;
                    break;
                case 'otro':
                    otrosMateriales++;
                    break;
            }
            if (bobina.entregaVacia) entregasVacias++;
        });
    });
    
    doc.setFontSize(12);
    doc.text(`Total de Devoluciones: ${totalDevoluciones}`, 25, yPos);
    yPos += 8;
    doc.text(`Total de Bobinas: ${totalBobinas}`, 25, yPos);
    yPos += 8;
    doc.text(`Bobinas con Cable: ${bobinasConCable}`, 25, yPos);
    yPos += 8;
    doc.text(`Bobinas Vacías: ${bobinasVacias}`, 25, yPos);
    yPos += 8;
    doc.text(`Otros Materiales: ${otrosMateriales}`, 25, yPos);
    yPos += 8;
    doc.text(`Entregas Vacías: ${entregasVacias}`, 25, yPos);
    yPos += 20;
    
    // Tabla detallada
    if (devoluciones.length > 0) {
        doc.setFontSize(14);
        doc.setTextColor(0, 0, 0);
        doc.text('Detalle de Devoluciones', 20, yPos);
        yPos += 15;
        
        // Headers
        doc.setFontSize(10);
        doc.setTextColor(255, 255, 255);
        doc.setFillColor(255, 85, 0);
        doc.rect(20, yPos - 8, 170, 8, 'F');
        
        doc.text('ID Obra', 25, yPos - 2);
        doc.text('Fecha', 90, yPos - 2);
        doc.text('Estado', 150, yPos - 2);
        
        yPos += 12;
        
        // Datos simplificados
        doc.setTextColor(0, 0, 0);
        devoluciones.forEach((devolucion, index) => {
            const fecha = new Date(devolucion.fechaEntrega).toLocaleDateString('es-ES');
            
            if (yPos > 250) {
                doc.addPage();
                yPos = 30;
            }
            
            // Alternar colores de fondo
            if (index % 2 === 0) {
                doc.setFillColor(245, 241, 230);
                doc.rect(20, yPos - 8, 170, 8, 'F');
            }
            
            // Solo ID Obra, Fecha y Estado (como pidió el usuario)
            doc.text(devolucion.idObra, 25, yPos - 2);
            doc.text(fecha, 90, yPos - 2);
            doc.text('Completada', 150, yPos - 2);
            
            yPos += 12; // Más espacio entre registros
        });
    }
    
    // Footer
    const pageCount = doc.internal.getNumberOfPages();
    for (let i = 1; i <= pageCount; i++) {
        doc.setPage(i);
        doc.setFontSize(8);
        doc.setTextColor(150, 150, 150);
        doc.text('Generado por Sistema de Control de Materiales - Redes Carreras S.L.', 20, 290);
        doc.text(`Página ${i} de ${pageCount}`, 170, 290);
    }
    
    // Descargar
    const nombreArchivo = `reporte_devoluciones_${fechaReporte.replace(/\//g, '-')}.pdf`;
    doc.save(nombreArchivo);
    
    mostrarToast('Reporte de devoluciones generado correctamente', 'success');
}

function generarReporte(tipo) {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();

    // Configurar fuentes
    doc.setFont('helvetica');
    
    // Header
    doc.setFontSize(20);
    doc.setTextColor(255, 85, 0); // Color primario
    doc.text('Redes Carreras S.L.', 20, 30);
    
    doc.setFontSize(16);
    doc.setTextColor(0, 0, 0);
    doc.text('Control de Materiales - Reporte', 20, 45);
    
    doc.setFontSize(12);
    doc.setTextColor(100, 100, 100);
    const fechaReporte = new Date().toLocaleDateString('es-ES');
    doc.text(`Fecha del reporte: ${fechaReporte}`, 20, 55);
    
    let yPos = 75;
    
    // Función para agregar tabla
    function agregarTabla(albaranesArray, titulo) {
        if (albaranesArray.length === 0) {
            doc.setFontSize(14);
            doc.setTextColor(100, 100, 100);
            doc.text(`${titulo}: No hay datos`, 20, yPos);
            yPos += 20;
            return;
        }

        doc.setFontSize(16);
        doc.setTextColor(0, 0, 0);
        doc.text(titulo, 20, yPos);
        yPos += 15;
        
        // Headers
        doc.setFontSize(10);
        doc.setTextColor(255, 255, 255);
        doc.setFillColor(255, 85, 0);
        doc.rect(20, yPos - 8, 170, 8, 'F');
        
        doc.text('ID Obra', 22, yPos - 2);
        doc.text('Fecha', 85, yPos - 2);
        doc.text('Tipo', 120, yPos - 2);
        doc.text('Estado', 150, yPos - 2);
        doc.text('Cuenta', 175, yPos - 2);
        
        yPos += 12;
        
        // Datos
        doc.setTextColor(0, 0, 0);
        albaranesArray.forEach((albaran, index) => {
            if (yPos > 250) { // Nueva página si es necesario
                doc.addPage();
                yPos = 30;
            }
            
            // Alternar colores de fondo
            if (index % 2 === 0) {
                doc.setFillColor(245, 241, 230);
                doc.rect(20, yPos - 8, 170, 8, 'F');
            }
            
            const fecha = new Date(albaran.fecha).toLocaleDateString('es-ES');
            const estado = albaran.estado === 'pendiente' ? 'Pendiente' : 
                          albaran.estado === 'recibido' ? 'Recibido' : 'Faltante';
            
            // Ajustar texto (sin truncar ID de obra)
            const obraText = albaran.idObra; // Sin truncamiento
            const cuentaText = albaran.cuentaCargo.length > 10 ? albaran.cuentaCargo.substring(0, 10) + '...' : albaran.cuentaCargo;
            
            doc.text(obraText, 22, yPos - 2);
            doc.text(fecha, 85, yPos - 2);
            doc.text(albaran.tipoInstalacion, 120, yPos - 2);
            doc.text(estado, 150, yPos - 2);
            doc.text(cuentaText, 175, yPos - 2);
            
            yPos += 8;
        });
        
        yPos += 15;
    }
    
    // Generar según el tipo
    switch(tipo) {
        case 'pendientes':
            const pendientes = albaranes.filter(a => a.estado === 'pendiente');
            agregarTabla(pendientes, 'Albaranes Pendientes');
            break;
            
        case 'recibidos':
            const recibidos = albaranes.filter(a => a.estado === 'recibido');
            agregarTabla(recibidos, 'Albaranes Recibidos');
            break;
            
        case 'faltantes':
            const faltantes = albaranes.filter(a => a.estado === 'faltante');
            agregarTabla(faltantes, 'Albaranes con Material Faltante');
            
            // Agregar detalles del material faltante
            if (faltantes.length > 0) {
                yPos += 10;
                doc.setFontSize(14);
                doc.setTextColor(0, 0, 0);
                doc.text('Detalles del Material Faltante', 20, yPos);
                yPos += 15;
                
                faltantes.forEach(albaran => {
                    if (albaran.materialFaltante) {
                        if (yPos > 250) {
                            doc.addPage();
                            yPos = 30;
                        }
                        
                        doc.setFontSize(10);
                        doc.setTextColor(255, 85, 0);
                        doc.text(`${albaran.id}:`, 25, yPos);
                        yPos += 6;
                        
                        doc.setTextColor(0, 0, 0);
                        const lineas = doc.splitTextToSize(albaran.materialFaltante, 150);
                        lineas.forEach(linea => {
                            doc.text(linea, 30, yPos);
                            yPos += 5;
                        });
                        yPos += 8;
                    }
                });
            }
            break;
            
        case 'cables':
            generarReporteMateriales('cable');
            break;
            
        case 'subconductos':
            generarReporteMateriales('subconducto');
            break;
            
        case 'devoluciones':
            generarReporteDevoluciones();
            break;
            
        case 'completo':
            // Resumen general
            doc.setFontSize(14);
            doc.setTextColor(0, 0, 0);
            doc.text('Resumen General', 20, yPos);
            yPos += 15;
            
            const total = albaranes.length;
            const pendientesCount = albaranes.filter(a => a.estado === 'pendiente').length;
            const recibidosCount = albaranes.filter(a => a.estado === 'recibido').length;
            const faltantesCount = albaranes.filter(a => a.estado === 'faltante').length;
            
            doc.setFontSize(12);
            doc.text(`Total de Albaranes: ${total}`, 25, yPos);
            yPos += 8;
            doc.text(`Pendientes: ${pendientesCount}`, 25, yPos);
            yPos += 8;
            doc.text(`Recibidos: ${recibidosCount}`, 25, yPos);
            yPos += 8;
            doc.text(`Con Material Faltante: ${faltantesCount}`, 25, yPos);
            yPos += 20;
            
            // Tablas detalladas
            agregarTabla(albaranes.filter(a => a.estado === 'pendiente'), 'Albaranes Pendientes');
            agregarTabla(albaranes.filter(a => a.estado === 'recibido'), 'Albaranes Recibidos');
            agregarTabla(albaranes.filter(a => a.estado === 'faltante'), 'Albaranes con Material Faltante');
            break;
    }
    
    // Footer en cada página
    const pageCount = doc.internal.getNumberOfPages();
    for (let i = 1; i <= pageCount; i++) {
        doc.setPage(i);
        doc.setFontSize(8);
        doc.setTextColor(150, 150, 150);
        doc.text('Generado por Sistema de Control de Materiales - Redes Carreras S.L.', 20, 290);
        doc.text(`Página ${i} de ${pageCount}`, 170, 290);
    }
    
    // Descargar
    const nombreArchivo = `reporte_albaranes_${tipo}_${fechaReporte.replace(/\//g, '-')}.pdf`;
    doc.save(nombreArchivo);
    
    mostrarToast('Reporte generado y descargado correctamente', 'success');
}

// ===== FUNCIONES MODALES MATERIALES =====
function abrirModalCableInstalacion() {
    document.getElementById('modalNuevoCable').classList.add('active');
    document.getElementById('idObraCable').focus();
    establecerFechaActualMaterial('Cable');
}

function cerrarModalCable() {
    document.getElementById('modalNuevoCable').classList.remove('active');
    document.getElementById('formNuevoCable').reset();
}

function abrirModalEntradaCable() {
    document.getElementById('modalEntradaCable').classList.add('active');
    document.getElementById('tipoCableEntrada').focus();
    establecerFechaActualMaterial('CableEntrada');
}

function cerrarModalEntradaCable() {
    document.getElementById('modalEntradaCable').classList.remove('active');
    document.getElementById('formEntradaCable').reset();
}

function abrirModalSubconductoInstalacion() {
    document.getElementById('modalNuevoSubconducto').classList.add('active');
    document.getElementById('idObraSubconducto').focus();
    establecerFechaActualMaterial('Subconducto');
}

function cerrarModalSubconducto() {
    document.getElementById('modalNuevoSubconducto').classList.remove('active');
    document.getElementById('formNuevoSubconducto').reset();
}

function abrirModalEntradaSubconducto() {
    document.getElementById('modalEntradaSubconducto').classList.add('active');
    document.getElementById('tipoSubconductoEntrada').focus();
    establecerFechaActualMaterial('SubconductoEntrada');
}

function cerrarModalEntradaSubconducto() {
    document.getElementById('modalEntradaSubconducto').classList.remove('active');
    document.getElementById('formEntradaSubconducto').reset();
}

function establecerFechaActualMaterial(tipo) {
    const hoy = new Date().toISOString().split('T')[0];
    const elementos = [
        `fechaCable`,
        `fechaSubconducto`, 
        `fechaCableEntrada`,
        `fechaSubconductoEntrada`
    ];
    
    elementos.forEach(elemento => {
        const elementoDOM = document.getElementById(elemento);
        if (elementoDOM) {
            elementoDOM.value = hoy;
        }
    });
}

function actualizarStockDisplay(tipo) {
    const stock = calcularStock(tipo);
    const prefijo = tipo === 'cable' ? 'cable' : 'subconducto';
    
    document.getElementById(`${prefijo}-recibido`).textContent = stock.recibido.toFixed(1);
    document.getElementById(`${prefijo}-instalado`).textContent = stock.instalado.toFixed(1);
    document.getElementById(`${prefijo}-disponible`).textContent = stock.disponible.toFixed(1);
}

// ===== FUNCIONES SIMPLES PARA NUEVOS BOTONES =====
// ===== EXPORTAR DATOS =====
function exportarDatos() {
    console.log('📤 Ejecutando exportarDatos()');
    try {
        console.log('📊 Datos a exportar:', {
            albaranes: albaranes.length,
            cables: cables.length,
            subconductos: subconductos.length,
            devoluciones: devoluciones.length
        });
        
        const datosCompletos = {
            timestamp: new Date().toISOString(),
            version: '1.0',
            albaranes: albaranes,
            cables: cables,
            subconductos: subconductos,
            devoluciones: devoluciones,
            metadata: {
                totalAlbaranes: albaranes.length,
                totalCables: cables.length,
                totalSubconductos: subconductos.length,
                totalDevoluciones: devoluciones.length
            }
        };
        
        const datosJson = JSON.stringify(datosCompletos, null, 2);
        const fecha = new Date().toISOString().split('T')[0];
        const nombreArchivo = `backup_materiales_${fecha}.json`;
        
        console.log('📁 Creando archivo:', nombreArchivo);
        
        // Crear y descargar archivo
        const blob = new Blob([datosJson], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = nombreArchivo;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
        
        console.log('✅ Archivo descargado correctamente');
        mostrarToast(`✅ Datos exportados correctamente: ${nombreArchivo}`, 'success');
    } catch (error) {
        console.error('❌ Error al exportar datos:', error);
        mostrarToast('❌ Error al exportar datos', 'error');
    }
}

// ===== IMPORTAR DATOS =====
function abrirModalImportar() {
    console.log('📥 Ejecutando abrirModalImportar()');
    const modal = document.getElementById('modalImportar');
    if (modal) {
        modal.classList.add('active');
        console.log('✅ Modal importar abierto');
        const archivoInput = document.getElementById('archivoImportar');
        const preview = document.getElementById('preview-import');
        const btnConfirmar = document.getElementById('btnConfirmarImportar');
        
        if (archivoInput) archivoInput.value = '';
        if (preview) preview.style.display = 'none';
        if (btnConfirmar) btnConfirmar.disabled = true;
    } else {
        console.error('❌ No se encontró el modal de importar');
    }
}

function cerrarModalImportar() {
    document.getElementById('modalImportar').classList.remove('active');
    document.getElementById('archivoImportar').value = '';
    document.getElementById('preview-import').style.display = 'none';
    document.getElementById('btnConfirmarImportar').disabled = true;
}

function procesarArchivoImportar() {
    const archivo = document.getElementById('archivoImportar').files[0];
    const preview = document.getElementById('preview-import');
    const btnConfirmar = document.getElementById('btnConfirmarImportar');
    
    if (!archivo) {
        preview.style.display = 'none';
        btnConfirmar.disabled = true;
        return;
    }
    
    if (!archivo.name.endsWith('.json')) {
        mostrarToast('❌ Solo se permiten archivos JSON', 'error');
        document.getElementById('archivoImportar').value = '';
        return;
    }
    
    const reader = new FileReader();
    reader.onload = function(e) {
        try {
            const datos = JSON.parse(e.target.result);
            
            // Validar estructura de datos
            if (!datos.albaranes || !datos.cables || !datos.subconductos || !datos.devoluciones) {
                throw new Error('Estructura de datos inválida');
            }
            
            // Mostrar preview
            mostrarPreviewImport(datos);
            btnConfirmar.disabled = false;
            
        } catch (error) {
            console.error('Error al procesar archivo:', error);
            mostrarToast('❌ Error al leer el archivo: formato inválido', 'error');
            document.getElementById('archivoImportar').value = '';
            preview.style.display = 'none';
            btnConfirmar.disabled = true;
        }
    };
    
    reader.readAsText(archivo);
}

function mostrarPreviewImport(datos) {
    const preview = document.getElementById('preview-import');
    
    const stats = {
        albaranes: datos.albaranes.length,
        cables: datos.cables.length,
        subconductos: datos.subconductos.length,
        devoluciones: datos.devoluciones.length
    };
    
    preview.innerHTML = `
        <h4>📊 Preview de Datos</h4>
        <p><strong>Archivo:</strong> ${datos.timestamp ? new Date(datos.timestamp).toLocaleDateString() : 'Fecha no disponible'}</p>
        <div class="import-stats">
            <div class="import-stat">
                <div class="stat-number">${stats.albaranes}</div>
                <div class="stat-label">Albaranes</div>
            </div>
            <div class="import-stat">
                <div class="stat-number">${stats.cables}</div>
                <div class="stat-label">Cables</div>
            </div>
            <div class="import-stat">
                <div class="stat-number">${stats.subconductos}</div>
                <div class="stat-label">Subconductos</div>
            </div>
            <div class="import-stat">
                <div class="stat-number">${stats.devoluciones}</div>
                <div class="stat-label">Devoluciones</div>
            </div>
        </div>
    `;
    
    preview.style.display = 'block';
}

function confirmarImportar() {
    const archivo = document.getElementById('archivoImportar').files[0];
    
    if (!archivo) {
        mostrarToast('❌ No hay archivo seleccionado', 'error');
        return;
    }
    
    if (confirm('⚠️ ¿Estás seguro de que quieres importar estos datos?\n\nEsto reemplazará TODOS los datos actuales y no se puede deshacer.')) {
        const reader = new FileReader();
        reader.onload = function(e) {
            try {
                const datos = JSON.parse(e.target.result);
                
                // Validar y cargar datos
                albaranes = datos.albaranes || [];
                cables = datos.cables || [];
                subconductos = datos.subconductos || [];
                devoluciones = datos.devoluciones || [];
                
                // Guardar en localStorage
                guardarAlbaranes();
                guardarMateriales();
                guardarDevoluciones();
                
                // Actualizar interfaz
                actualizarContadores();
                mostrarAlbaranes();
                actualizarStockDisplay('cable');
                actualizarStockDisplay('subconducto');
                mostrarDevoluciones();
                
                cerrarModalImportar();
                mostrarToast(`✅ Datos importados correctamente`, 'success');
                
            } catch (error) {
                console.error('Error al importar datos:', error);
                mostrarToast('❌ Error al importar los datos', 'error');
            }
        };
        
        reader.readAsText(archivo);
    }
}

// ===== FUNCIONES SIMPLES PARA NUEVOS BOTONES =====
function abrirBuscador() {
    // Abrir modal del buscador
    document.getElementById('modalBuscador').classList.add('active');
    document.getElementById('buscarObra').value = '';
    document.getElementById('buscarObra').focus();
    mostrarResultadosIniciales();
}

function cerrarModalBuscador() {
    document.getElementById('modalBuscador').classList.remove('active');
}

function mostrarResultadosIniciales() {
    document.getElementById('resultados-busqueda').innerHTML = '<div class="no-results"><p>💡 Ingresa un ID de obra para comenzar la búsqueda</p></div>';
}

function buscarEnTiempoReal() {
    const termino = document.getElementById('buscarObra').value.trim();
    const resultadosContainer = document.getElementById('resultados-busqueda');
    
    if (termino.length < 2) {
        mostrarResultadosIniciales();
        return;
    }
    
    // Buscar en todos los datos
    const resultados = {
        albaranes: buscarAlbaranes(termino),
        cables: buscarCables(termino),
        subconductos: buscarSubconductos(termino),
        devoluciones: buscarDevoluciones(termino)
    };
    
    // Mostrar resultados
    mostrarResultadosBusqueda(resultados);
}

function buscarAlbaranes(termino) {
    return albaranes.filter(albaran => 
        albaran.idObra.toLowerCase().includes(termino.toLowerCase()) ||
        albaran.id.toLowerCase().includes(termino.toLowerCase()) ||
        albaran.cuentaCargo.toLowerCase().includes(termino.toLowerCase())
    );
}

function buscarCables(termino) {
    return cables.filter(cable => 
        cable.idObra.toLowerCase().includes(termino.toLowerCase()) ||
        cable.id.toLowerCase().includes(termino.toLowerCase()) ||
        cable.tipoCable.toLowerCase().includes(termino.toLowerCase())
    );
}

function buscarSubconductos(termino) {
    return subconductos.filter(subconducto => 
        subconducto.idObra.toLowerCase().includes(termino.toLowerCase()) ||
        subconducto.id.toLowerCase().includes(termino.toLowerCase()) ||
        subconducto.tipoSubconducto.toLowerCase().includes(termino.toLowerCase())
    );
}

function buscarDevoluciones(termino) {
    return devoluciones.filter(devolucion => 
        devolucion.idObra.toLowerCase().includes(termino.toLowerCase()) ||
        devolucion.id.toLowerCase().includes(termino.toLowerCase())
    );
}

function mostrarResultadosBusqueda(resultados) {
    const container = document.getElementById('resultados-busqueda');
    const totalResultados = Object.values(resultados).reduce((sum, arr) => sum + arr.length, 0);
    
    if (totalResultados === 0) {
        container.innerHTML = '<div class="resultado-vacio">🔍 No se encontraron resultados para la búsqueda</div>';
        return;
    }
    
    let html = '';
    
    // Albaranes
    if (resultados.albaranes.length > 0) {
        html += '<div class="resultado-seccion">';
        html += '<h3>📋 Albaranes</h3>';
        resultados.albaranes.forEach(albaran => {
            const estadoIcon = albaran.estado === 'pendiente' ? '📋' : 
                              albaran.estado === 'recibido' ? '✅' : '⚠️';
            html += `
                <div class="resultado-item">
                    <div class="item-header">
                        <span class="item-id">${estadoIcon} ${albaran.id}</span>
                        <span class="item-fecha">${formatDate(albaran.fecha)}</span>
                    </div>
                    <div class="item-details">
                        <div class="detail-item">
                            <span class="detail-label">ID Obra:</span>
                            <span class="detail-value">${albaran.idObra}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Estado:</span>
                            <span class="detail-value">${albaran.estado.toUpperCase()}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Instalación:</span>
                            <span class="detail-value">${albaran.tipoInstalacion}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Cuenta:</span>
                            <span class="detail-value">${albaran.cuentaCargo}</span>
                        </div>
                    </div>
                </div>
            `;
        });
        html += '</div>';
    }
    
    // Cables
    if (resultados.cables.length > 0) {
        html += '<div class="resultado-seccion">';
        html += '<h3>🔌 Cables</h3>';
        resultados.cables.forEach(cable => {
            html += `
                <div class="resultado-item">
                    <div class="item-header">
                        <span class="item-id">🔌 ${cable.id}</span>
                        <span class="item-fecha">${formatDate(cable.fecha)}</span>
                    </div>
                    <div class="item-details">
                        <div class="detail-item">
                            <span class="detail-label">ID Obra:</span>
                            <span class="detail-value">${cable.idObra}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Tipo:</span>
                            <span class="detail-value">${cable.tipoCable}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Metros:</span>
                            <span class="detail-value">${cable.metros} m</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Categoría:</span>
                            <span class="detail-value">${cable.categoria || 'Instalación'}</span>
                        </div>
                    </div>
                </div>
            `;
        });
        html += '</div>';
    }
    
    // Subconductos
    if (resultados.subconductos.length > 0) {
        html += '<div class="resultado-seccion">';
        html += '<h3>🛡️ Subconductos</h3>';
        resultados.subconductos.forEach(subconducto => {
            html += `
                <div class="resultado-item">
                    <div class="item-header">
                        <span class="item-id">🛡️ ${subconducto.id}</span>
                        <span class="item-fecha">${formatDate(subconducto.fecha)}</span>
                    </div>
                    <div class="item-details">
                        <div class="detail-item">
                            <span class="detail-label">ID Obra:</span>
                            <span class="detail-value">${subconducto.idObra}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Tipo:</span>
                            <span class="detail-value">${subconducto.tipoSubconducto}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Metros:</span>
                            <span class="detail-value">${subconducto.metros} m</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Categoría:</span>
                            <span class="detail-value">${subconducto.categoria || 'Instalación'}</span>
                        </div>
                    </div>
                </div>
            `;
        });
        html += '</div>';
    }
    
    // Devoluciones
    if (resultados.devoluciones.length > 0) {
        html += '<div class="resultado-seccion">';
        html += '<h3>↩️ Devoluciones</h3>';
        resultados.devoluciones.forEach(devolucion => {
            const totalBobinas = devolucion.bobinas ? devolucion.bobinas.length : 0;
            html += `
                <div class="resultado-item">
                    <div class="item-header">
                        <span class="item-id">↩️ ${devolucion.id}</span>
                        <span class="item-fecha">${formatDate(devolucion.fecha)}</span>
                    </div>
                    <div class="item-details">
                        <div class="detail-item">
                            <span class="detail-label">ID Obra:</span>
                            <span class="detail-value">${devolucion.idObra}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Bobinas:</span>
                            <span class="detail-value">${totalBobinas}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Instalación:</span>
                            <span class="detail-value">${devolucion.tipoInstalacion}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Total Metros:</span>
                            <span class="detail-value">${calcularTotalMetrosDevolucion(devolucion)} m</span>
                        </div>
                    </div>
                </div>
            `;
        });
        html += '</div>';
    }
    
    container.innerHTML = html;
}

function calcularTotalMetrosDevolucion(devolucion) {
    if (!devolucion.bobinas) return 0;
    return devolucion.bobinas.reduce((total, bobina) => total + (parseFloat(bobina.metros) || 0), 0);
}

function exportarDatosSimple() {
    try {
        // Crear datos de backup
        const datos = {
            timestamp: new Date().toISOString(),
            albaranes: albaranes,
            cables: cables,
            subconductos: subconductos,
            devoluciones: devoluciones
        };
        
        // Descargar archivo
        const blob = new Blob([JSON.stringify(datos, null, 2)], {type: 'application/json'});
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `backup_${new Date().toISOString().split('T')[0]}.json`;
        link.click();
        URL.revokeObjectURL(url);
        
        alert('✅ Datos exportados correctamente');
    } catch (error) {
        alert('❌ Error al exportar: ' + error.message);
    }
}

function abrirImportar() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    input.onchange = function(e) {
        const archivo = e.target.files[0];
        if (archivo) {
            const reader = new FileReader();
            reader.onload = function(e) {
                try {
                    const datos = JSON.parse(e.target.result);
                    if (confirm('¿Seguro que quieres importar estos datos? Esto reemplazará todos los datos actuales.')) {
                        albaranes = datos.albaranes || [];
                        cables = datos.cables || [];
                        subconductos = datos.subconductos || [];
                        devoluciones = datos.devoluciones || [];
                        
                        // Guardar datos
                        guardarAlbaranes();
                        guardarMateriales();
                        guardarDevoluciones();
                        
                        // Actualizar interfaz
                        actualizarContadores();
                        mostrarAlbaranes();
                        actualizarStockDisplay('cable');
                        actualizarStockDisplay('subconducto');
                        mostrarDevoluciones();
                        
                        alert('✅ Datos importados correctamente');
                    }
                } catch (error) {
                    alert('❌ Error al leer el archivo: ' + error.message);
                }
            };
            reader.readAsText(archivo);
        }
    };
    input.click();
}

// ===== FORMATO DE FECHA =====
function formatDate(fecha) {
    if (!fecha) return 'N/A';
    return new Date(fecha).toLocaleDateString('es-ES');
}